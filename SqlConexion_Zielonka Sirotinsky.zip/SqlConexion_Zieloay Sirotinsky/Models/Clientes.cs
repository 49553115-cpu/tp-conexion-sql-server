public class Clientes
{
    public int idCliente {get;set;}
    public string nombre {get;set;}
    public string apellido{get;set;}
    public int dni{get;set;}
    public DateTime fechaNacimiento{get;set;}
    public string email{get;set;}



}