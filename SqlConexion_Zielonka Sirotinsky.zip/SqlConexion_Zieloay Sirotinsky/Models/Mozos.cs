public class Mozos
{
    public int Id_Mozo { get; set; }
    public string Nombre { get; set; }
    public string Apellido { get; set; }
}