public class RegistroMesasComidas
{
    public int idRegistroMesasComidas{get;set;}
    public int idRegistroMesa{get;set;}
    public int IdComida {get;set;}
    public int cantidad {get;set;}
    public double precio{get;set;}
}