public class TipoComidas
{
    public int idTiposComida{get;set;}
    public string nombre{get;set;}
}