public class Mesas{
    public int id_Mesa{get;set;}
    public int numero{get;set;}
}