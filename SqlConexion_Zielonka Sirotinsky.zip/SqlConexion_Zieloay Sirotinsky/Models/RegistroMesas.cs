public class RegistroMesas
{
    public int Id_registro{get;set;}
    public int Id_mesa{get;set;}
    public int Id_Mozo{get;set;}
    public int Id_Cliente {get;set;}
    public DateTime fecha{get;set;}
    
}