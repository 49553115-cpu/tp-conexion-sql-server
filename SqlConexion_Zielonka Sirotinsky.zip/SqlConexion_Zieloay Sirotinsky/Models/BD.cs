using Microsoft.Data.SqlClient;
using Dapper;
using SqlConexion.Models;
using System.Collections.Generic;
using System.Linq;

public static class BD
{
    private static string connectionString = @"Server=localhost;Database=ORT Gourmet;Integrated Security=true;TrustServerCertificate=true;";

    public static List<Clientes> TraerClientes()
    {
        using (SqlConnection db = new SqlConnection(connectionString))
        {
            string query = "SELECT * FROM Clientes";
            return db.Query<Clientes>(query).ToList();
        }
    }

    public static void EliminarClientePorNombre(string nombre)
    {
        using (SqlConnection db = new SqlConnection(connectionString))
        {
            string sql = "DELETE FROM Clientes WHERE Nombre = @nombre";
            db.Execute(sql, new { nombre });
        }
    }



    public static Mozos TraerMozoPorId(int Id_Mozo)
    {
        using (SqlConnection db = new SqlConnection(connectionString))
        {
            string sql = "SELECT * FROM Mozos WHERE Id_Mozo = @Id_Mozo";
            return db.QueryFirstOrDefault<Mozos>(sql, new { Id_Mozo });
        }
    }

    public static void ModificarMozo(Mozos mozo)
    {
        using (SqlConnection db = new SqlConnection(connectionString))
        {
            string sql = @"UPDATE Mozos SET Nombre = @Nombre, Apellido = @Apellido WHERE IdMozo = @IdMozo";
            db.Execute(sql, mozo);
        }
    }


    public static void AgregarComida(Comidass comida)
    {
        using (SqlConnection db = new SqlConnection(connectionString))
        {
            string sql = @"INSERT INTO Comidas (Nombre, IdTipoComida, Precio, SinGluten)
                           VALUES (@Nombre, @IdTipoComida, @Precio, @SinGluten)";
            db.Execute(sql, comida);
        }
    }

    public static List<RegistroMesas> TraerRegistrosMesas()
    {
        using (SqlConnection db = new SqlConnection(connectionString))
        {
            string sql = "SELECT * FROM RegistroMesas";
            return db.Query<RegistroMesas>(sql).ToList();
        }
    }
}
