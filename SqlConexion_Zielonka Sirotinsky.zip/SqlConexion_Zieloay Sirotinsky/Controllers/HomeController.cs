using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SqlConexion.Models;
using System.Collections.Generic;

namespace SqlConexion.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ListarClientes()
        {
            var clientes = BD.TraerClientes();
            return View(clientes);
        }

        public IActionResult EliminarCliente()
        {
            return View(); 
        }

        [HttpPost]
        public IActionResult EliminarCliente(string nombre)
        {
            if (!string.IsNullOrEmpty(nombre))
            {
                BD.EliminarClientePorNombre(nombre);
            }

            return RedirectToAction("ListarClientes");
        }

        public IActionResult EditarMozo(int id)
        {
            Mozos mozo = BD.TraerMozoPorId(id);
            if (mozo == null) return NotFound();
            return View();
        }

        [HttpPost]
        public IActionResult EditarMozos(Mozos mozo)
        {
            if (ModelState.IsValid)
            {
                BD.ModificarMozo(mozo);
                return RedirectToAction("ListarClientes");
            }

            return View();
        }       


        public IActionResult AgregarComida()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AgregarComida(Comidass comida)
        {
            if (ModelState.IsValid)
            {
                BD.AgregarComida(comida);
                return RedirectToAction("ListarClientes");
            }
            return View(comida);
        }

        public IActionResult ListarRegistrosMesas()
        {
            var lista = BD.TraerRegistrosMesas();
            return View(lista);
        }
    }
}
